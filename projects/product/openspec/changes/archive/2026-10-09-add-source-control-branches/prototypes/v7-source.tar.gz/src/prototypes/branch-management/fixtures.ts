import type { SourceControlCommit, SourceControlRepository, SourceControlWorktree } from '../../features/code/source-control-model';
import type { BranchEntry } from '../../features/code/components/SourceControlBranchPanel';
import { sourceControlRepositories } from '../source-control/fixtures';

export type BranchFixture = { repositories: SourceControlRepository[]; entries: Record<string, BranchEntry[]>; graph: Record<string, Record<string, string[]>>; heads: Record<string, Record<string, string>> };
export const observedAt = '2026-10-08T10:32:00+08:00';
export const remoteObservedAt = '2026-10-08T10:20:00+08:00';
export const refName = (ref: string) => ref.replace(/^refs\/(heads|remotes)\//, '');
export const localRef = (name: string) => 'refs/heads/' + name;
const hash = (seed: string) => Array.from(seed).map(char => char.charCodeAt(0).toString(16).padStart(2, '0')).join('').repeat(20).slice(0, 40);

/** Each reference points to an explicit vertex; histories follow parents, never name order. */
export function reachableCommits(repository: SourceControlRepository, graph: BranchFixture['graph'][string], tip?: string): SourceControlCommit[] {
  const found = new Set<string>();
  const visit = (value?: string) => { if (!value || found.has(value)) return; found.add(value); (graph[value] || []).forEach(visit); };
  visit(tip);
  return repository.commits.filter(commit => found.has(commit.hash));
}

export function makeBranchFixture(state: string): BranchFixture {
  const entries: BranchFixture['entries'] = {}, graph: BranchFixture['graph'] = {}, heads: BranchFixture['heads'] = {};
  const repositories = sourceControlRepositories.slice(0, 3).map((sample, repositoryIndex) => {
    const repository = structuredClone(sample);
    repository.simulated = true;
    const sourceFiles = repository.commits.flatMap(commit => commit.files);
    const vertices: Array<[string, string, string | null, number]> = repository.id === 'buildr' ? [
      ['d4', 'feat(code): 统一查看工作位置与成果', 'd3', 8],
      ['r2', 'fix(reader): 保留文件选择与阅读位置', 'r1', 8],
      ['m3', 'release: 更新稳定版本说明', 'm2', 8],
      ['f2', 'feat(review): 添加成果审看摘要', 'f1', 8],
      ['u2', 'docs: 补充上游使用说明', 'b1', 7],
      ['r1', 'fix(reader): 优化窄屏文件阅读', 'd3', 7],
      ['d3', 'feat(code): 增加任务与提交关联', 'd2', 7],
      ['f1', 'feat(review): 建立审看工作入口', 'm2', 7],
      ['d2', 'refactor(code): 统一代码阅读来源', 'b1', 6],
      ['m2', 'docs(product): 更新产品使用说明', 'b1', 6],
      ['b1', 'feat(code): 建立源代码管理基础', null, 5],
    ] : [
      [repositoryIndex === 1 ? 'e3' : 'c3', repositoryIndex === 1 ? 'feat(examples): 增加协作示例' : 'docs: 更新工作空间指南', repositoryIndex === 1 ? 'e2' : 'c2', 8],
      [repositoryIndex === 1 ? 'e2' : 'c2', repositoryIndex === 1 ? 'docs(examples): 完善接入说明' : 'docs: 整理阅读路径', null, 6],
    ];
    graph[repository.id] = Object.fromEntries(vertices.map(([seed, , parent]) => [hash(seed), parent ? [hash(parent)] : []]));
    const tips: Record<string, string> = repository.id === 'buildr' ? {
      'refs/heads/dev': hash('d4'), 'refs/heads/main': hash('m2'), 'refs/heads/codex/reader-fix': hash('r2'),
      'refs/remotes/origin/dev': hash('d3'), 'refs/remotes/origin/main': hash('m3'),
      'refs/remotes/origin/feature/review': hash('f2'), 'refs/remotes/upstream/main': hash('u2'),
    } : {'refs/heads/main': hash(vertices[0][0]), 'refs/remotes/origin/main': hash(vertices[0][0])};
    heads[repository.id] = tips;
    repository.commits = vertices.map(([seed, subject, , day], index) => {
      const value = sourceFiles[index % Math.max(sourceFiles.length, 1)];
      const files = value ? [{...value, repositoryId: repository.id}] : [];
      return {repositoryId: repository.id, hash: hash(seed), shortHash: hash(seed).slice(0, 8), subject,
        authorName: index % 3 ? '陈俊' : 'Buildr 团队', authorEmail: index % 3 ? 'branch-author@example.com' : 'buildr-team@example.com', authoredAt: `2026-10-${String(day).padStart(2, '0')}T09:${String(45 - index).padStart(2, '0')}:00+08:00`,
        committedAt: `2026-10-${String(day).padStart(2, '0')}T09:${String(45 - index).padStart(2, '0')}:00+08:00`, message: subject + '\n\n这是一条离线模拟提交（Commit），用于查看成果与文件差异（Diff）。',
        branches: Object.entries(tips).filter(([, tip]) => tip === hash(seed)).map(([ref]) => refName(ref)), tags: [], files,
        ...(seed === 'r2' ? {taskId: 'reader-fix', taskTitle: '改善文件阅读体验'} : {})};
    });
    const makeWorktree = (value: SourceControlWorktree, branch: string | null, changes: SourceControlWorktree['changes']) => ({...value, branch,
      head: tips[localRef(branch || 'dev')], changes: changes.map(file => ({...file, worktreeId: value.worktreeId})), fileCount: new Set(changes.map(file => file.path)).size,
      commits: reachableCommits(repository, graph[repository.id], tips[localRef(branch || 'dev')]), status: changes.length ? 'ready' as const : 'clean' as const, observedRevision: 'scm:branch-prototype-' + value.worktreeId,
      upstream: branch === 'dev' ? 'origin/dev' : branch === 'main' ? 'origin/main' : null, ahead: branch === 'dev' ? 1 : 0, behind: branch === 'main' && repository.id === 'buildr' ? 1 : 0});
    const mainBranch = repository.id === 'buildr' ? state === 'detached' ? null : 'dev' : 'main';
    const mainChanges = repository.id === 'buildr' && state === 'dirty' ? sample.changes.slice(0, 3) : [];
    repository.worktrees = [makeWorktree(repository.worktrees[0], mainBranch, mainChanges)];
    if (repository.id === 'buildr') {
      const secondary = makeWorktree({...sample.worktrees[1], name: 'reader-fix', location: sample.location + '/.worktrees/reader-fix', taskId: 'reader-fix', taskTitle: '改善文件阅读体验'}, 'codex/reader-fix', sample.changes.slice(0, 3));
      repository.worktrees.push(secondary);
    }
    repository.worktreeCount = repository.worktrees.length;
    repository.branch = mainBranch;
    repository.branches = Object.keys(tips).filter(ref => ref.startsWith('refs/heads/')).map(refName);
    repository.changes = repository.worktrees.flatMap(worktree => worktree.changes);
    repository.status = repository.changes.length ? 'ready' : 'clean';
    repository.fileCount = repository.worktrees.reduce((sum, worktree) => sum + (worktree.fileCount || 0), 0);
    repository.head = repository.worktrees[0].head;
    repository.ahead = repository.worktrees[0].ahead;
    repository.behind = repository.worktrees[0].behind;
    repository.observedRevision = 'scm:branch-prototype-' + repository.id;
    entries[repository.id] = Object.entries(tips).map(([ref, tip]) => {
      const commit = repository.commits.find(item => item.hash === tip)!;
      const remote = ref.startsWith('refs/remotes/') ? refName(ref).split('/')[0] : undefined;
      const occupied = repository.worktrees.find(worktree => worktree.branch === refName(ref));
      const upstream = ref === localRef('dev') ? 'origin/dev' : ref === localRef('main') ? 'origin/main' : undefined;
      return {ref, name: refName(ref), kind: remote ? 'remote' as const : 'local' as const, remote, tip, subject: commit.subject,
        author: commit.authorName, updatedAt: commit.committedAt, upstream, ahead: ref === localRef('dev') ? 1 : 0,
        behind: ref === localRef('main') && repository.id === 'buildr' ? 1 : 0, worktreeId: occupied?.worktreeId, taskTitle: occupied?.taskTitle || undefined};
    });
    return repository;
  });
  if (state === 'empty') Object.keys(entries).forEach(id => { entries[id] = []; heads[id] = {}; });
  return {repositories, entries, graph, heads};
}
