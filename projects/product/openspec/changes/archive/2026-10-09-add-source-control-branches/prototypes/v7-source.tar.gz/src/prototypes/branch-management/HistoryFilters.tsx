import { useMemo } from 'react';
import { Button, Select, Tooltip } from 'antd';
import { ReloadOutlined } from '@ant-design/icons';
import { SourceControlBranchPicker } from '../../features/code/components/SourceControlBranchPicker';
import type { BranchEntry } from '../../features/code/components/SourceControlBranchPanel';
import type { SourceControlRepository, SourceControlWorktree } from '../../features/code/source-control-model';
import './history-filters.css';

export type HistoryFiltersProps = {
  repository: SourceControlRepository;
  worktree: SourceControlWorktree;
  entries: BranchEntry[];
  branchRef: string;
  authorEmail: string;
  remoteLoading: boolean;
  remoteUpdatedAt: string;
  remoteError: string;
  query: string;
  onBranchChange(ref: string): void;
  onAuthorChange(email: string): void;
  onClear(): void;
  onRefreshRemote(): void;
};

type AuthorOption = { value: string; label: string; name: string; email: string; search: string; duplicateName: boolean };

export function HistoryFilters({ repository, worktree, entries, branchRef, authorEmail, remoteLoading, remoteUpdatedAt, remoteError, query, onBranchChange, onAuthorChange, onClear, onRefreshRemote }: HistoryFiltersProps) {
  const authors = useMemo(() => {
    const byEmail = new Map<string, string>();
    repository.commits.forEach(commit => {
      if (commit.authorEmail && !byEmail.has(commit.authorEmail)) byEmail.set(commit.authorEmail, commit.authorName || commit.authorEmail);
    });
    const nameCounts = new Map<string, number>();
    byEmail.forEach(name => nameCounts.set(name, (nameCounts.get(name) || 0) + 1));
    const options: AuthorOption[] = [{ value: '', label: '作者：全部', name: '全部作者', email: '', search: '全部作者', duplicateName: false }];
    byEmail.forEach((name, email) => options.push({ value: email, label: `作者：${name}`, name, email, search: `${name} ${email}`, duplicateName: (nameCounts.get(name) || 0) > 1 }));
    return options;
  }, [repository.commits]);
  const branchName = branchRef === 'HEAD' ? '当前' : entries.find(entry => entry.ref === branchRef)?.name || branchRef.replace(/^refs\/(heads|remotes)\//, '');
  const active = branchRef !== 'HEAD' || Boolean(authorEmail) || Boolean(query.trim());

  return <div className="branch-history-filters" data-prototype-position="history-filter-controls" role="group" aria-label="提交历史筛选">
    <div className="branch-history-filter-branch" title={`分支：${branchName}`}>
      <SourceControlBranchPicker entries={entries} value={branchRef} currentBranch={worktree.branch} currentHead={worktree.head} remoteLoading={remoteLoading} remoteUpdatedAt={remoteUpdatedAt} remoteError={remoteError} onChange={onBranchChange} onRefreshRemote={onRefreshRemote} label={`分支：${branchName}`} separateCurrentScope />
    </div>
    <Select<string, AuthorOption> className="branch-history-filter-author" size="small" value={authorEmail} onChange={onAuthorChange} options={authors} showSearch optionFilterProp="search" aria-label="筛选提交作者" title={authors.find(author => author.value === authorEmail)?.label || '作者：全部'} popupClassName="branch-history-author-popup" popupMatchSelectWidth={false} optionRender={option => <span className="branch-history-author-option"><span>{option.data.name}</span>{option.data.duplicateName && <small>{option.data.email}</small>}</span>} />
    <Tooltip title="重置关键词、分支和作者"><span className="branch-history-filter-reset"><Button size="small" type="text" className="branch-history-filter-clear" icon={<ReloadOutlined />} disabled={!active} aria-label="重置筛选条件" onClick={onClear}>重置</Button></span></Tooltip>
  </div>;
}
