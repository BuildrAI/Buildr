import { useEffect, useMemo, useRef, useState } from 'react';
import { Button, Spin, message } from 'antd';
import { SourceControlWorkbench, type SourceControlBranchExtension } from '../../features/code/components/SourceControlWorkbench';
import type { BranchEntry } from '../../features/code/components/SourceControlBranchPanel';
import type { SourceControlChange, SourceControlReader, SourceControlRepository, SourceControlScene, SourceControlWorktree } from '../../features/code/source-control-model';
import type { CodeSourceControlInput } from '../../features/code/api/code-api';
import { formatShortDateTime } from '../../lib/taskLabels';
import { localRef, makeBranchFixture, observedAt, reachableCommits, remoteObservedAt } from './fixtures';
import { BranchManagementPopover, type BranchSwitchImpact } from './BranchManagementPopover';
import { HistoryFilters } from './HistoryFilters';
import './preview.css';

type Props = { page: string; state: string; onNavigate(page: string, state?: string): void };
const sourceKey = (repositoryId: string, worktreeId: string) => repositoryId + ':' + worktreeId;
const remoteLocalName = (entry: BranchEntry) => entry.name.slice((entry.remote || 'origin').length + 1);
const validName = (name: string) => Boolean(name && !name.startsWith('-') && !name.startsWith('/') && !name.endsWith('/') && !name.endsWith('.') && !name.endsWith('.lock') && !/[\s~^:?*\[\\]/.test(name) && !name.includes('..') && !name.includes('//') && !name.includes('@{') && name !== '@' && !name.split('/').some(part => part.startsWith('.')));

/** Offline boundary: all mutations affect React memory only, with no live client imports. */
export function MockBranchWorkbench({page, state = 'clean', onNavigate}: Props) {
  const [fixture, setFixture] = useState(() => makeBranchFixture(state));
  const [readAt, setReadAt] = useState(observedAt);
  const [historyRefs, setHistoryRefs] = useState<Record<string, string>>({});
  const [source, setSource] = useState({repositoryId: 'buildr', worktreeId: 'mock-buildr-main'});
  const [selection, setSelection] = useState({key: 'branch-prototype-initial', ...source});
  const [remoteTimes, setRemoteTimes] = useState<Record<string, string>>({buildr: remoteObservedAt});
  const [remoteErrors, setRemoteErrors] = useState<Record<string, string>>({});
  const [remoteLoading, setRemoteLoading] = useState<Record<string, boolean>>({});
  const [localLoading, setLocalLoading] = useState(false);
  const [authors, setAuthors] = useState<Record<string, string>>({});
  const [toast, contextHolder] = message.useMessage();
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const remoteAttempt = useRef<Record<string, number>>({});
  const epoch = useRef(0);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  useEffect(() => {
    const next = makeBranchFixture(state), main = next.repositories[0].worktrees[0];
    timers.current.forEach(clearTimeout); timers.current = []; remoteAttempt.current = {};
    setFixture(next); setSource({repositoryId: 'buildr', worktreeId: main.worktreeId});
    setSelection({key: 'branch-prototype-' + state + '-' + ++epoch.current, repositoryId: 'buildr', worktreeId: main.worktreeId});
    const selected = state === 'occupied' ? localRef('codex/reader-fix') : state === 'remote-failure' ? 'refs/remotes/origin/main' : 'HEAD';
    setHistoryRefs({[sourceKey('buildr', main.worktreeId)]: selected});
    setRemoteTimes({buildr: remoteObservedAt, examples: remoteObservedAt, docs: remoteObservedAt});
    setRemoteErrors(state === 'remote-failure' ? {buildr: '模拟网络失败，保留上次成功记录。'} : {});
    setRemoteLoading({}); setLocalLoading(false); setReadAt(observedAt); setAuthors({});
  }, [state]);
  const navigate = (next: string) => onNavigate(next, state);
  const viewedRef = (repository: SourceControlRepository, worktree: SourceControlWorktree) => historyRefs[sourceKey(repository.id, worktree.worktreeId)] || 'HEAD';
  const selectedRepository = fixture.repositories.find(repository => repository.id === source.repositoryId);
  const selectedWorktree = selectedRepository?.worktrees.find(worktree => worktree.worktreeId === source.worktreeId);
  const currentHistoryRef = selectedRepository && selectedWorktree ? viewedRef(selectedRepository, selectedWorktree) : undefined;
  const sourceChange = (repositoryId: string, worktreeId: string) => {
    if (source.repositoryId === repositoryId && source.worktreeId === worktreeId) return;
    setSource({repositoryId, worktreeId});
    setHistoryRefs(previous => ({...previous, [sourceKey(repositoryId, worktreeId)]: 'HEAD'}));
    setAuthors(previous => ({...previous, [sourceKey(repositoryId, worktreeId)]: ''}));
  };
  const pickHistory = (repository: SourceControlRepository, worktree: SourceControlWorktree, ref: string) => {
    setHistoryRefs(previous => ({...previous, [sourceKey(repository.id, worktree.worktreeId)]: ref}));
    navigate('history');
  };
  const trackedLocal = (repository: SourceControlRepository, entry: BranchEntry) => entry.kind === 'remote' ? fixture.entries[repository.id]?.find(item => item.kind === 'local' && item.upstream === entry.name) : entry;
  const openPosition = (repository: SourceControlRepository, worktree: SourceControlWorktree, nextPage: string) => {
    setSelection({key: 'branch-open-position-' + ++epoch.current, repositoryId: repository.id, worktreeId: worktree.worktreeId});
    setSource({repositoryId: repository.id, worktreeId: worktree.worktreeId});
    setHistoryRefs(previous => ({...previous, [sourceKey(repository.id, worktree.worktreeId)]: 'HEAD'}));
    setAuthors(previous => ({...previous, [sourceKey(repository.id, worktree.worktreeId)]: ''}));
    navigate(nextPage);
  };
  function remoteRefresh(repositoryId: string) {
    if (remoteLoading[repositoryId]) return;
    setRemoteLoading(previous => ({...previous, [repositoryId]: true}));
    timers.current.push(setTimeout(() => {
      const attempt = (remoteAttempt.current[repositoryId] || 0) + 1; remoteAttempt.current[repositoryId] = attempt;
      setRemoteLoading(previous => ({...previous, [repositoryId]: false}));
      if (state === 'remote-failure' && repositoryId === 'buildr' && attempt === 1) setRemoteErrors(previous => ({...previous, [repositoryId]: '模拟网络失败，保留上次成功记录。可重试。'}));
      else { setRemoteTimes(previous => ({...previous, [repositoryId]: new Date().toISOString()})); setRemoteErrors(previous => ({...previous, [repositoryId]: ''})); void toast.success('远程记录已更新。'); }
    }, 500));
  }
  const reader = useMemo<SourceControlReader>(() => {
    const findRepository = (input: CodeSourceControlInput, signal: AbortSignal) => { signal.throwIfAborted(); const repository = fixture.repositories.find(item => item.id === input.repositoryId); if (!repository) throw Error('模拟代码库（Repository）不存在。'); return repository; };
    const checkout = (repository: SourceControlRepository, input: CodeSourceControlInput) => repository.worktrees.find(worktree => worktree.worktreeId === input.worktreeId) || repository.worktrees[0];
    const responseSource = (repository: SourceControlRepository, input: CodeSourceControlInput) => {
      const worktree = checkout(repository, input);
      return {repositoryId: repository.id, checkoutId: worktree.worktreeId, worktreeGroupId: worktree.isMain ? 'main' : 'mock-name:' + worktree.name, worktreeId: worktree.worktreeId, taskId: null, commitHash: input.commitHash || null,
        location: worktree.location, version: input.commitHash ? input.commitHash + ' · 历史文件' : (worktree.branch || worktree.head?.slice(0, 8)) + (input.area === 'staged' ? ' · 已暂存版本' : ' · 当前文件'), kind: input.commitHash ? 'commit' as const : worktree.isMain ? 'default' as const : 'worktree' as const};
    };
    const meta = (revision: string, limit = 100, truncated = false, nextCursor: string | null = null) => ({readAt, observedRevision: revision, diagnostics: [], coverage: {limit, truncated, nextCursor}});
    const commit = (repository: SourceControlRepository, hash: string, input: CodeSourceControlInput) => {
      const value = repository.commits.find(item => item.hash === hash); if (!value) throw Error('模拟提交（Commit）不存在。');
      return {...value, worktreeId: checkout(repository, input).worktreeId, parents: fixture.graph[repository.id][hash] || [], taskId: value.taskId || null, taskTitle: value.taskTitle || null, taskDiagnostic: null};
    };
    const currentFile = (repository: SourceControlRepository, input: CodeSourceControlInput): SourceControlChange => {
      const files = input.area === 'commit' && input.commitHash ? commit(repository, input.commitHash, input).files : checkout(repository, input).changes;
      const file = files.find(item => item.path === input.path && (input.area === 'commit' || item.area === input.area));
      if (!file) throw Error('模拟文件不存在。'); return file;
    };
    return {
      history: async (input, signal) => {
        const repository = findRepository(input, signal), worktree = checkout(repository, input);
        const tip = input.branch ? fixture.heads[repository.id][input.branch] || (repository.commits.some(item => item.hash === input.branch) ? input.branch : undefined) : worktree.head || undefined;
        const reachable = reachableCommits(repository, fixture.graph[repository.id], tip);
        const query = input.query?.trim().toLowerCase(), matches = reachable.filter(item => !query || [item.subject, item.authorName, item.hash, item.taskId].join(' ').toLowerCase().includes(query));
        const offset = Number(input.cursor || 0), limit = input.limit || 100, values = matches.slice(offset, offset + limit), remaining = offset + limit < matches.length;
        return {...meta(worktree.observedRevision || '', limit, remaining, remaining ? String(offset + limit) : null), source: responseSource(repository, input), branches: fixture.entries[repository.id].map(entry => ({name: entry.name, hash: entry.tip, current: entry.kind === 'local' && entry.name === worktree.branch, upstream: entry.upstream || null})), commits: values.map(item => commit(repository, item.hash, input))};
      },
      commit: async (input, signal) => { const repository = findRepository(input, signal), value = commit(repository, input.commitHash || '', input); return {...meta('git:' + value.hash), source: responseSource(repository, input), commit: value, baseHash: value.parents[0] || null, files: value.files.map(file => ({...file, worktreeId: checkout(repository, input).worktreeId, area: 'commit' as const}))}; },
      diff: async (input, signal) => { const repository = findRepository(input, signal), file = currentFile(repository, input), value = input.commitHash ? commit(repository, input.commitHash, input) : null; return {...meta(value ? 'git:' + value.hash : checkout(repository, input).observedRevision || ''), source: responseSource(repository, input), area: input.area || 'unstaged', file: {...file, worktreeId: checkout(repository, input).worktreeId, area: input.area || file.area}, patch: file.preview, binary: false, baseHash: value?.parents[0] || null}; },
      sourceFile: async (input, signal) => {
        const repository = findRepository(input, signal), file = currentFile(repository, input), blob = 'f'.repeat(40), revision = input.area === 'staged' ? 'index:' + blob + ':100644' : input.commitHash ? 'git:' + input.commitHash + ':' + blob : 'current:branch-prototype-' + checkout(repository, input).worktreeId + ':' + file.path;
        return {...meta(revision, 5 * 1024 * 1024), source: responseSource(repository, input), path: file.path, kind: file.path.endsWith('.md') ? 'markdown' : 'text', content: file.content, mediaType: '', sizeBytes: new TextEncoder().encode(file.content).length, limitBytes: 5 * 1024 * 1024, truncated: false, digest: 'sha256-' + 'f'.repeat(64), revision, page: null, observedAt: readAt, message: ''};
      },
    };
  }, [fixture, readAt]);
  const refreshLocal = () => new Promise<void>(resolve => { setLocalLoading(true); timers.current.push(setTimeout(() => { setReadAt(new Date().toISOString()); setLocalLoading(false); if (state === 'loading') onNavigate(page, 'clean'); resolve(); }, 500)); });
  const sourceId = selectedRepository && selectedWorktree ? sourceKey(selectedRepository.id, selectedWorktree.worktreeId) : '';
  const selectedAuthor = authors[sourceId] || '';
  function inspect(repository: SourceControlRepository, worktree: SourceControlWorktree, entry: BranchEntry, override?: string): BranchSwitchImpact {
    const localName = entry.kind === 'remote' ? override?.trim() || trackedLocal(repository, entry)?.name || remoteLocalName(entry) : entry.name;
    const existing = fixture.entries[repository.id].find(item => item.ref === localRef(localName));
    const conflict = Boolean(entry.kind === 'remote' && existing && existing.upstream !== entry.name);
    const same = !conflict && (entry.kind === 'local' && entry.name === worktree.branch || entry.kind === 'remote' && existing?.name === worktree.branch);
    const occupied = !conflict ? repository.worktrees.find(item => item.branch === localName && item.worktreeId !== worktree.worktreeId) : undefined;
    const affectedFiles = state === 'dirty' && worktree.isMain && ['refs/heads/main', 'refs/remotes/origin/main', 'refs/remotes/upstream/main'].includes(entry.ref) ? worktree.changes.filter(file => file.area === 'unstaged').map(file => file.path) : [];
    const blockedReason = localLoading || state === 'loading' ? '正在读取工作位置，请稍后再试。' : worktree.status === 'offline' ? '这个工作位置暂不可读取。' : worktree.status === 'partial' || worktree.fileCount === null || !worktree.location || !entry.tip ? '工作位置尚未完整读取，请先刷新。' : '';
    const description = entry.kind === 'remote' ? existing && !conflict ? '使用本地 ' + localName + ' 的当前成果；不会自动更新到远程记录。' : '从 ' + entry.name + ' 使用对应本地分支（Local Branch）。' : '只切换这个目录使用的分支（Branch）。';
    return {localName, same, occupied, affectedFiles, blockedReason, needsLocalName: conflict, createTracking: entry.kind === 'remote' && !existing, description};
  }
  function useBranch(repository: SourceControlRepository, worktree: SourceControlWorktree, entry: BranchEntry, override?: string): boolean {
    const impact = inspect(repository, worktree, entry, override);
    if (impact.same || impact.occupied || impact.affectedFiles.length || impact.blockedReason) return false;
    if (!validName(impact.localName) || impact.needsLocalName) { void toast.warning('这个本地名称不可使用，请换一个名称。'); return false; }
    const observed = fixture.repositories.find(item => item.id === repository.id)?.worktrees.find(item => item.worktreeId === worktree.worktreeId);
    const observedEntry = fixture.entries[repository.id]?.find(item => item.ref === entry.ref);
    if (!observed || observed.branch !== worktree.branch || observed.head !== worktree.head || observed.observedRevision !== worktree.observedRevision || !observedEntry || observedEntry.tip !== entry.tip) { void toast.warning('工作位置或分支（Branch）记录已改变，请重新选择。'); return false; }
    const ref = localRef(impact.localName), create = !fixture.heads[repository.id][ref];
    const usedTip = !create && entry.kind === 'remote' ? fixture.heads[repository.id][ref] : entry.tip;
    setFixture(previous => {
      const next = structuredClone(previous), repo = next.repositories.find(item => item.id === repository.id)!;
      if (create) {
        next.heads[repository.id][ref] = entry.tip;
        next.entries[repository.id].push({...entry, kind: 'local', remote: undefined, name: impact.localName, ref, upstream: entry.kind === 'remote' ? entry.name : undefined, worktreeId: undefined, taskTitle: undefined, ahead: 0, behind: 0});
        repo.branches.push(impact.localName);
        repo.commits = repo.commits.map(commit => commit.hash === entry.tip ? {...commit, branches: [...commit.branches, impact.localName]} : commit);
      }
      const target = repo.worktrees.find(item => item.worktreeId === worktree.worktreeId)!;
      target.branch = impact.localName; target.head = usedTip; target.upstream = next.entries[repo.id].find(item => item.ref === ref)?.upstream;
      target.commits = reachableCommits(repo, next.graph[repo.id], usedTip); target.ahead = next.entries[repo.id].find(item => item.ref === ref)?.ahead ?? 0; target.behind = next.entries[repo.id].find(item => item.ref === ref)?.behind ?? 0;
      target.observedRevision = 'scm:branch-prototype-' + ++epoch.current;
      if (target.isMain) { repo.branch = impact.localName; repo.head = usedTip; repo.ahead = target.ahead; repo.behind = target.behind; }
      next.entries[repo.id] = next.entries[repo.id].map(item => item.worktreeId === target.worktreeId ? {...item, worktreeId: undefined, taskTitle: undefined} : item);
      next.entries[repo.id] = next.entries[repo.id].map(item => item.ref === ref ? {...item, worktreeId: target.worktreeId, taskTitle: target.taskTitle || undefined} : item);
      return next;
    });
    // Explicit history filters stay independent; HEAD naturally follows the new working tip.
    setReadAt(new Date().toISOString());
    void toast.success('已在演示中切换 ' + (worktree.isMain ? '主工作位置' : worktree.name) + ' 到 ' + impact.localName + '。');
    return true;
  }
  const extension: SourceControlBranchExtension = {
    historyBranch: currentHistoryRef === 'HEAD' ? undefined : currentHistoryRef,
    historyFilterKey: selectedAuthor || undefined,
    filterHistoryCommits: commits => selectedAuthor ? commits.filter(commit => commit.authorEmail === selectedAuthor) : commits,
    selection, onSourceChange: sourceChange, rowAction: () => {}, context: () => null,
    rowControl: (repository, worktree, ready) => <BranchManagementPopover repository={repository} worktree={worktree} entries={fixture.entries[repository.id] || []} ready={ready} remoteLoading={Boolean(remoteLoading[repository.id])} remoteUpdatedAt={formatShortDateTime(remoteTimes[repository.id] || '')} remoteError={remoteErrors[repository.id] || ''} onRefreshRemote={() => remoteRefresh(repository.id)} inspect={entry => inspect(repository, worktree, entry)} onUse={(entry, localName) => useBranch(repository, worktree, entry, localName)} onOpenPosition={target => openPosition(repository, target, 'history')} onViewChanges={() => openPosition(repository, worktree, 'changes')} />,
    historyControls: (repository, worktree, controls) => {
      const id = sourceKey(repository.id, worktree.worktreeId);
      return <><HistoryFilters repository={repository} worktree={worktree} entries={fixture.entries[repository.id] || []} branchRef={viewedRef(repository, worktree)} authorEmail={authors[id] || ''} remoteLoading={Boolean(remoteLoading[repository.id])} remoteUpdatedAt={formatShortDateTime(remoteTimes[repository.id] || '')} remoteError={remoteErrors[repository.id] || ''} query={controls?.query || ''} onBranchChange={ref => pickHistory(repository, worktree, ref)} onAuthorChange={email => setAuthors(previous => ({...previous, [id]: email}))} onClear={() => { setHistoryRefs(previous => ({...previous, [id]: 'HEAD'})); setAuthors(previous => ({...previous, [id]: ''})); controls?.clearSearch(); }} onRefreshRemote={() => remoteRefresh(repository.id)} />{state === 'loading' && <div className="branch-preview-history-loading"><Spin size="small" /><small>正在读取历史…</small><Button type="link" size="small" onClick={() => void refreshLocal()}>完成模拟读取</Button></div>}</>;
    },
  };
  const scene: SourceControlScene = page === 'history' ? 'history' : page === 'full-file' ? 'full-file' : 'changes';
  return <>{contextHolder}<SourceControlWorkbench repositories={fixture.repositories} scene={scene} reader={reader} readKey="branch-offline-prototype" observation={{loading: localLoading || state === 'loading', error: '', readAt: state === 'loading' ? '' : readAt, diagnostics: []}} onRefresh={refreshLocal} onScene={navigate} onOpenTask={() => void toast.info('这里仅展示关联任务（Task）。')} onOpenFile={() => {}} onViewCurrent={() => navigate('changes')} branchExtension={extension} /></>;
}
