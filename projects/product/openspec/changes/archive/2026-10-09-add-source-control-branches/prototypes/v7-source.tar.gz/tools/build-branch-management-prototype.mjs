import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { gzipSync } from 'node:zlib';
import { build } from 'vite';

const root = path.resolve(import.meta.dirname, '..');
const [output, viewerOutput] = process.argv.slice(2);
if (!output || !viewerOutput) throw Error('Usage: node tools/build-branch-management-prototype.mjs <body.html> <viewer.html>');
const metadata = JSON.parse(await fs.readFile(path.join(root, 'src/prototypes/branch-management/scenes.json'), 'utf8'));
const observedAt = new Date().toISOString();
const commit = execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim();
const json = value => JSON.stringify(value).replaceAll('<', '\\u003c');
const featureAssets = path.resolve(root, '../buildr/resources/workspace/skills/buildr/ui-prototype/assets');
async function document(entry, viewer = false, define = {}) {
  const sources = new Set();
  const result = await build({
    root, configFile: false,
    plugins: [{
      name: 'offline-source-control-prototype', enforce: 'pre',
      resolveId(source, importer) {
        if (importer?.endsWith('/features/workbench/components/WorkbenchTaskRow.tsx') && source === '../hooks/useWorkbenchPreferences')
          return path.join(root, 'src/prototypes/source-control/mock-preferences.ts');
      },
      transform(_code, id) { if (id.startsWith(root + '/src/') || id.startsWith(featureAssets + '/')) sources.add(id.split('?')[0]); },
    }],
    build: { write: false, minify: true, assetsInlineLimit: Infinity,
      lib: { entry: path.join(root, 'src/prototypes/branch-management', entry), name: viewer ? 'BuildrSourceControlReader' : 'BuildrSourceControlPrototype', formats: ['iife'] },
      rollupOptions: { onwarn(warning, warn) { if (warning.code !== 'MODULE_LEVEL_DIRECTIVE') warn(warning); }, output: { inlineDynamicImports: true } },
    }, define: { 'process.env.NODE_ENV': '"production"', ...define },
  });
  const chunks = (Array.isArray(result) ? result : [result]).flatMap(item => item.output);
  const script = chunks.filter(item => item.type === 'chunk').map(item => item.code).join('\n');
  const css = chunks.filter(item => item.type === 'asset' && item.fileName.endsWith('.css')).map(item => item.source).join('\n');
  const observation = { observedAt, commit,
    uncommittedSummary: '讨论候选第七版：行内工作分支只显示短名称并收窄，完整名称可按需查看。管理小浮层只突出当前动作；远程独有项直接检出并创建本地跟踪分支、切换目标工作位置，已有本地项复用其当前成果。关键词、分支、作者组合筛选保留，固定同排重置按钮一次恢复默认条件。所有业务操作仅在内存模拟；复用应用壳、共享来源历史差异阅读和统一原型阅读器，第二至第六版原型HTML及候选源码保全',
    sources: await Promise.all([...sources].sort().map(async source => ({ path: path.relative(root, source), sha256: crypto.createHash('sha256').update(await fs.readFile(source)).digest('hex') }))),
  };
  const html = '<!doctype html>\n' + (viewer ? '<!-- buildr:ui-prototype-viewer -->' : '<!-- buildr:ui-prototype -->') + '\n<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Buildr 分支管理与历史筛选 · ' + (viewer ? '原型阅读器' : '原型') + '</title>'
    + (viewer ? '' : '<script id="buildr-prototype" type="application/json">' + json(metadata) + '</script>')
    + '<script id="buildr-prototype-source" type="application/json">' + json(observation) + '</script><style>' + css.replaceAll('</style', '<\\/style') + '</style></head><body><div id="root"></div><script>' + script.replaceAll('</script', '<\\/script') + '</script></body></html>\n';
  if (Buffer.byteLength(html) > 2 * 1024 * 1024) throw Error('Prototype exceeds 2 MiB: ' + Buffer.byteLength(html));
  return html;
}
async function save(target, html) {
  await fs.mkdir(path.dirname(path.resolve(target)), { recursive: true });
  await fs.writeFile(target + '.pending', html);
  await fs.rename(target + '.pending', target);
  console.log(JSON.stringify({ output: path.resolve(target), bytes: Buffer.byteLength(html), pages: metadata.pages.length, commit }));
}
const body = await document('main.tsx');
await save(output, body);
await save(viewerOutput, await document('viewer.tsx', true, {
  __PROTOTYPE_DOCUMENT_GZIP__: JSON.stringify(gzipSync(body).toString('base64')),
  __PROTOTYPE_DOCUMENT_BYTES__: String(Buffer.byteLength(body)), __PROTOTYPE_OBSERVED_AT__: JSON.stringify(observedAt),
}));
