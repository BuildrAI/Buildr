import { useEffect, useMemo, useState } from 'react';
import { Empty, Segmented, Tag } from 'antd';
import { FileTextOutlined, SwapOutlined } from '@ant-design/icons';
import type { SourceControlCommit, SourceControlRepository, SourceControlWorktree } from '../../features/code/source-control-model';
import type { BranchEntry } from '../../features/code/components/SourceControlBranchPanel';
import { pairForSplit, type DiffRow } from '../../features/task/components/diff-text';
import { formatShortDateTime } from '../../lib/taskLabels';
import './branch-comparison.css';

export type BranchComparisonProps = {
  repository: SourceControlRepository;
  worktree: SourceControlWorktree;
  entry: BranchEntry;
  graph: Record<string, string[]>;
  kind: 'compare-branch' | 'compare-files';
};

function reachable(graph: Record<string, string[]>, tip?: string | null) {
  const result = new Set<string>();
  const visit = (hash: string) => {
    if (result.has(hash)) return;
    result.add(hash);
    (graph[hash] || []).forEach(visit);
  };
  if (tip) visit(tip);
  return result;
}

type Snapshot = Record<string, string>;
const webRoot = 'projects/product/services/buildr-web/src/';
const workbenchPath = webRoot + 'features/code/components/SourceControlWorkbench.tsx';
const stylePath = webRoot + 'features/code/source-control.css';
const taskRowPath = webRoot + 'features/workbench/components/WorkbenchTaskRow.tsx';
const overviewPath = 'projects/product/knowledge/docs/overview.md';
const text = (lines: string[]) => lines.join('\n') + '\n';

/** Independent, representative file trees. Commit.files is deliberately not used as a tree. */
function demoSnapshot(repositoryId: string, tip?: string | null): Snapshot | null {
  if (!tip) return null;
  const seed = [tip.slice(0, 2), tip.slice(2, 4)].map(value => String.fromCharCode(Number.parseInt(value, 16))).join('');
  if (repositoryId === 'buildr') {
    if (!['b1', 'd2', 'd3', 'd4', 'r1', 'r2', 'm2', 'm3', 'f1', 'f2', 'u2'].includes(seed)) return null;
    const development = ['d2', 'd3', 'd4', 'r1', 'r2'].includes(seed);
    const taskLinks = ['d3', 'd4', 'r1', 'r2'].includes(seed);
    const review = seed.startsWith('f');
    return {
      [workbenchPath]: text(development ? [
        'export function SourceControlWorkbench({ repositories }) {',
        '  const selected = repositories.filter(repository => repository.available);',
        ...(seed === 'r2' ? ['  const readingPosition = useReadingPosition();'] : []),
        '  return (',
        '    <section aria-label="源代码管理">',
        '      <RepositoryList repositories={repositories} />',
        ...(taskLinks ? ['      <TaskCommitLinks repositories={selected} />'] : []),
        ...(seed === 'd4' ? ['      <BranchHistoryScope repositories={selected} />'] : []),
        '      <ChangeReader repositories={selected} />',
        '    </section>',
        '  );',
        '}',
      ] : review ? [
        'export function SourceControlWorkbench() {',
        '  return (',
        '    <section aria-label="成果审看">',
        '      <RepositoryList />',
        ...(seed === 'f2' ? ['      <ReviewSummary />'] : []),
        '      <ChangeReader />',
        '    </section>',
        '  );',
        '}',
      ] : ['export function SourceControlWorkbench() {', '  return <p>源代码管理待建设</p>;', '}']),
      [stylePath]: text(development || review ? [
        '.source-control { display: flex; height: 100%; }',
        `.source-control-sidebar { width: ${seed.startsWith('r') ? 320 : 360}px; flex: none; }`,
        '.source-control-reader { flex: 1; min-width: 0; }',
      ] : ['.source-control { padding: 24px; }']),
      [taskRowPath]: text(['<Link className="workbench-task-title">{record.title}</Link>']),
      [overviewPath]: text([
        '# Buildr', '', 'Buildr 管理工作资产。',
        ...(seed.startsWith('m') ? ['', '从代码区域查看已登记的代码库与成果。'] : []),
        ...(seed === 'm3' ? ['', '稳定版本已更新，可查看最新使用说明。'] : []),
        ...(seed === 'u2' ? ['', '上游使用说明：每个代码库保留独立的工作位置。'] : []),
        ...(review ? ['', '从成果审看入口查看交付内容。'] : []),
      ]),
    };
  }
  if (repositoryId === 'examples' && ['e2', 'e3'].includes(seed)) return {
    'src/WorkspaceExample.tsx': text(seed === 'e3' ? ['export const repositories = [', '  "Buildr",', '  "examples",', '  "docs",', '];'] : ['export const repositories = ["Buildr"];']),
    'README.md': text(['# Buildr 示例', '', seed === 'e3' ? '展示多个代码库在同一工作空间中的协作。' : '一个简单示例。']),
  };
  if (repositoryId === 'docs' && ['c2', 'c3'].includes(seed)) return {
    'guide/workspace.md': text(['# 工作空间', ...(seed === 'c3' ? ['', '在一个工作空间中查看所有已登记代码库。'] : [])]),
  };
  return null;
}

/** Exact line comparison for the small mock snapshots, with unchanged rows retained. */
function compareLines(before?: string, after?: string): DiffRow[] {
  const lines = (content?: string) => content ? content.replace(/\n$/, '').split('\n') : [];
  const left = lines(before), right = lines(after);
  const common = Array.from({length: left.length + 1}, () => Array<number>(right.length + 1).fill(0));
  for (let i = left.length - 1; i >= 0; i--) for (let j = right.length - 1; j >= 0; j--) {
    common[i][j] = left[i] === right[j] ? common[i + 1][j + 1] + 1 : Math.max(common[i + 1][j], common[i][j + 1]);
  }
  const rows: DiffRow[] = [];
  let i = 0, j = 0;
  while (i < left.length || j < right.length) {
    if (i < left.length && j < right.length && left[i] === right[j]) {
      rows.push({kind: 'ctx', oldNo: i + 1, newNo: j + 1, text: left[i]}); i++; j++;
    } else if (i < left.length && (j >= right.length || common[i + 1][j] >= common[i][j + 1])) {
      rows.push({kind: 'del', oldNo: i + 1, newNo: null, text: left[i]}); i++;
    } else {
      rows.push({kind: 'add', oldNo: null, newNo: j + 1, text: right[j]}); j++;
    }
  }
  return rows;
}

function CommitList({title, commits}: {title: string; commits: SourceControlCommit[]}) {
  return <section className="branch-comparison-commits" aria-label={title}>
    <header><h3>{title}</h3><span>{commits.length}</span></header>
    {commits.length ? <ol>{commits.map(commit => <li key={commit.hash}>
      <strong>{commit.subject}</strong>
      <div><code>{commit.shortHash}</code><span>{commit.authorName}</span><time>{formatShortDateTime(commit.committedAt)}</time></div>
    </li>)}</ol> : <p className="branch-comparison-empty">没有独有提交（Commit）</p>}
  </section>;
}

export function BranchComparison({repository, worktree, entry, graph, kind}: BranchComparisonProps) {
  const [selectedPath, setSelectedPath] = useState('');
  const [comparisonView, setComparisonView] = useState<'commits' | 'files'>('commits');
  useEffect(() => { setSelectedPath(''); setComparisonView('commits'); }, [entry.ref, worktree.worktreeId, kind]);
  const comparison = useMemo(() => {
    const current = reachable(graph, worktree.head), selected = reachable(graph, entry.tip);
    return {
      currentOnly: repository.commits.filter(commit => current.has(commit.hash) && !selected.has(commit.hash)),
      selectedOnly: repository.commits.filter(commit => selected.has(commit.hash) && !current.has(commit.hash)),
      shared: [...current].filter(hash => selected.has(hash)).length,
    };
  }, [repository.commits, graph, worktree.head, entry.tip]);
  const files = useMemo(() => {
    const current = demoSnapshot(repository.id, worktree.head), selected = demoSnapshot(repository.id, entry.tip);
    if (!current || !selected) return null;
    const working = {...current};
    if (kind === 'compare-files') {
      // Staged contents first, then the actual unstaged/untracked contents in this mock working tree.
      const overlays = [...worktree.changes].sort((a, b) => Number(b.area === 'staged') - Number(a.area === 'staged'));
      for (const change of overlays) {
        if (change.status === 'deleted') delete working[change.path];
        else working[change.path] = change.content;
        if (change.previousPath && change.previousPath !== change.path) delete working[change.previousPath];
      }
    }
    return [...new Set([...Object.keys(working), ...Object.keys(selected)])].sort().filter(path => working[path] !== selected[path]).map(path => ({
      path, current: working[path], selected: selected[path], rows: compareLines(working[path], selected[path]),
    }));
  }, [repository.id, worktree.head, worktree.changes, entry.tip, kind]);
  const activeFile = files?.find(file => file.path === selectedPath) || files?.[0];
  const pairs = activeFile ? pairForSplit(activeFile.rows) : [];
  const pendingCount = worktree.fileCount ?? new Set(worktree.changes.map(file => file.path)).size;
  const currentName = worktree.branch || '当前提交（Commit）';

  return <section className="branch-comparison" aria-label={kind === 'compare-branch' ? '双方提交比较' : '工作位置文件比较'} data-prototype-position="branch-comparison">
    <p className="branch-comparison-direction"><SwapOutlined /><span>以当前工作位置为左侧，查看所选成果的区别。</span><Tag>只读</Tag></p>
    <div className="branch-comparison-sides">
      <article aria-label="比较左侧：当前工作位置"><small>当前工作位置 · {repository.name}</small><strong>{currentName}</strong><code>{worktree.head?.slice(0, 8) || '尚无提交（Commit）'}</code><span title={worktree.location}>{worktree.location}</span></article>
      <article aria-label="比较右侧：所选成果"><small>所选成果 · {entry.kind === 'remote' ? '远程分支（Remote Branch）' : '本地分支（Local Branch）'}</small><strong>{entry.name}</strong><code>{entry.tip.slice(0, 8)}</code><span>{entry.subject}</span></article>
    </div>
    <div className="branch-comparison-view-controls">
    <p className="branch-comparison-scope" data-prototype-position="comparison-scope">{kind === 'compare-branch'
      ? <>比较已提交成果 · 共同包含 {comparison.shared} 个提交（Commit） · 当前 {pendingCount} 个未提交文件不参与本次比较</>
      : <>比较此处文件与 {entry.name} · 包含此处 {pendingCount} 个未提交文件</>}</p>
    {kind === 'compare-branch' && <Segmented size="small" aria-label="比较内容" data-prototype-position="comparison-view" value={comparisonView} onChange={value => setComparisonView(value as 'commits' | 'files')} options={[{value: 'commits', label: '提交'}, {value: 'files', label: '文件差异'}]} />}
    </div>
    {kind === 'compare-branch' && comparisonView === 'commits' ? <div className="branch-comparison-commit-grid">
      <CommitList title="当前工作位置独有" commits={comparison.currentOnly} />
      <CommitList title="所选成果独有" commits={comparison.selectedOnly} />
    </div> : <>
      <p className="branch-comparison-demo">演示差异 · 原型使用代表性文件；正式版本需读取两侧完整文件差异。</p>
      {!files ? <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="该成果尚未准备文件比较示例" /> : !files.length ? <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="两个演示文件快照一致" /> : <div className="branch-comparison-files" data-prototype-position="comparison-files">
        <nav aria-label="演示差异文件"><header>文件 · {files.length}<small>右侧相对左侧</small></header>{files.map(file => {
          const added = file.rows.filter(row => row.kind === 'add').length, deleted = file.rows.filter(row => row.kind === 'del').length;
          return <button type="button" className={file.path === activeFile?.path ? 'is-selected' : ''} aria-label={`比较文件 ${file.path}`} aria-pressed={file.path === activeFile?.path} key={file.path} onClick={() => setSelectedPath(file.path)}>
            <FileTextOutlined /><span><strong>{file.path.split('/').at(-1)}</strong><small title={file.path}>{file.path}</small></span><em><b>+{added}</b><i>−{deleted}</i></em>
          </button>;
        })}</nav>
        <div className="branch-comparison-diff" role="region" aria-label="演示文件左右差异">
          <div className="branch-comparison-diff-head"><strong>{activeFile?.path.split('/').at(-1)}</strong><small>{activeFile?.path}</small></div>
          <div className="branch-comparison-diff-labels"><span>{kind === 'compare-branch' ? `${currentName} · 已提交` : '当前工作位置'}{activeFile?.current === undefined ? ' · 文件不存在' : ''}</span><span>{entry.name}{activeFile?.selected === undefined ? ' · 文件不存在' : ''}</span></div>
          <div className="branch-comparison-diff-scroll">{pairs.map((pair, index) => <div className="branch-comparison-diff-row" key={index}>
            <div className={pair.left?.kind === 'del' ? 'is-removed' : ''}><i>{pair.left?.oldNo ?? ''}</i><code>{pair.left?.text || ' '}</code></div>
            <div className={pair.right?.kind === 'add' ? 'is-added' : ''}><i>{pair.right?.newNo ?? ''}</i><code>{pair.right?.text || ' '}</code></div>
          </div>)}</div>
        </div>
      </div>}
    </>}
  </section>;
}
