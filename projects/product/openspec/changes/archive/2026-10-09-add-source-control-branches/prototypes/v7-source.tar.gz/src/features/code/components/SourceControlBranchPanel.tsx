import { useMemo, useState } from 'react';
import { Alert, Button, Empty, Input } from 'antd';
import { ArrowRightOutlined, BranchesOutlined, CheckOutlined, CloudOutlined, HistoryOutlined, RobotOutlined, SearchOutlined, SyncOutlined } from '@ant-design/icons';
import { formatShortDateTime } from '../../../lib/taskLabels';
import './source-control-branches.css';

export type BranchEntry = {
  ref: string;
  name: string;
  kind: 'local' | 'remote';
  remote?: string;
  tip: string;
  subject: string;
  author: string;
  updatedAt: string;
  upstream?: string | null;
  ahead?: number | null;
  behind?: number | null;
  worktreeId?: string;
  taskTitle?: string;
};

export type SourceControlBranchListProps = {
  entries: BranchEntry[];
  selectedRef: string;
  currentBranch: string | null;
  remoteLoading: boolean;
  remoteUpdatedAt: string;
  remoteError: string;
  onSelect(ref: string): void;
  onRefreshRemote(): void;
};

type BranchGroup = { key: string; title: string; entries: BranchEntry[] };

function groupedBranches(entries: BranchEntry[]): BranchGroup[] {
  const local = entries.filter(entry => entry.kind === 'local');
  const remotes = Array.from(new Set(entries.filter(entry => entry.kind === 'remote').map(entry => entry.remote || 'origin')));
  remotes.sort((left, right) => {
    const order = (value: string) => value === 'origin' ? 0 : value === 'upstream' ? 1 : 2;
    return order(left) - order(right) || left.localeCompare(right);
  });
  return [
    { key: 'local', title: '本地分支（Local Branch）', entries: local },
    ...remotes.map(remote => ({ key: remote, title: `${remote} · 远程分支（Remote Branch）`, entries: entries.filter(entry => entry.kind === 'remote' && (entry.remote || 'origin') === remote) })),
  ].filter(group => group.entries.length > 0);
}

function trackingSummary(entry: BranchEntry): string {
  if (!entry.upstream) return '';
  if (entry.ahead == null || entry.behind == null) return '差异待更新';
  if (!entry.ahead && !entry.behind) return '与已读取记录一致';
  return [entry.ahead ? `领先 ${entry.ahead}` : '', entry.behind ? `落后 ${entry.behind}` : ''].filter(Boolean).join(' · ');
}

export function SourceControlBranchList({ entries, selectedRef, currentBranch, remoteLoading, remoteUpdatedAt, remoteError, onSelect, onRefreshRemote }: SourceControlBranchListProps) {
  const [query, setQuery] = useState('');
  const filtered = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase();
    return normalized ? entries.filter(entry => [entry.name, entry.ref, entry.subject, entry.remote, entry.taskTitle].filter(Boolean).join(' ').toLocaleLowerCase().includes(normalized)) : entries;
  }, [entries, query]);
  const groups = groupedBranches(filtered);

  return <section className="source-control-branch-list" data-prototype-position="branch-list" aria-label="分支（Branch）清单">
    <div className="source-control-branch-search">
      <Input allowClear prefix={<SearchOutlined />} value={query} onChange={event => setQuery(event.target.value)} placeholder="搜索名称、成果或任务（Task）" aria-label="搜索全部分支（Branch）" />
      <small>选中查看详情 · 当前文件保持不变</small>
    </div>
    <div className="source-control-branch-scroll" role="listbox" aria-label="可查看的分支（Branch）" aria-activedescendant={filtered.some(entry => entry.ref === selectedRef) ? `branch-option-${encodeURIComponent(selectedRef)}` : undefined}>
      {groups.length ? groups.map(group => <div className="source-control-branch-group" key={group.key} role="group" aria-label={group.title}>
        <div className="source-control-branch-group-title"><span>{group.title}</span><small>{group.entries.length}</small></div>
        {group.entries.map(entry => {
          const isCurrent = entry.kind === 'local' && entry.name === currentBranch;
          const elsewhere = entry.kind === 'local' && Boolean(entry.worktreeId) && !isCurrent;
          return <button type="button" role="option" id={`branch-option-${encodeURIComponent(entry.ref)}`} aria-selected={entry.ref === selectedRef} className={`source-control-branch-row${entry.ref === selectedRef ? ' is-selected' : ''}`} onClick={() => onSelect(entry.ref)} key={entry.ref} title={entry.name}>
            <span className="source-control-branch-row-icon">{entry.kind === 'remote' ? <CloudOutlined /> : <BranchesOutlined />}</span>
            <span className="source-control-branch-row-copy">
              <span className="source-control-branch-name"><strong>{entry.name}</strong>{isCurrent && <span className="source-control-branch-badge is-current"><CheckOutlined />当前使用</span>}{elsewhere && <span className="source-control-branch-badge">其他位置使用</span>}</span>
              <span className="source-control-branch-subject">{entry.subject}</span>
              {entry.taskTitle && <span className="source-control-branch-task">任务（Task）· {entry.taskTitle}</span>}
            </span>
          </button>;
        })}
      </div>) : <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={query.trim() ? "没有匹配项" : "当前没有分支（Branch）记录"} />}
    </div>
    <div className="source-control-branch-remote" data-prototype-position="remote-refresh">
      <div><span>远程记录</span><Button size="small" type="text" icon={<SyncOutlined spin={remoteLoading} />} loading={remoteLoading} onClick={onRefreshRemote} aria-label="更新远程记录">更新</Button></div>
      <small>{remoteLoading ? '正在获取最新记录…' : remoteUpdatedAt ? `上次更新 ${remoteUpdatedAt}` : '尚未更新'}</small>
      {remoteError && <Alert type="warning" showIcon message={remoteError} />}
    </div>
  </section>;
}

export type SourceControlBranchDetailProps = {
  entry?: BranchEntry;
  repositoryName: string;
  worktree: { name: string; location: string; branch: string | null; fileCount: number | null; worktreeId: string };
  occupied?: { name: string; location: string };
  onViewHistory(): void;
  onUse(): void;
  onOpenWorktree(): void;
  onAgent(): void;
};

export function SourceControlBranchDetail({ entry, repositoryName, worktree, occupied, onViewHistory, onUse, onOpenWorktree, onAgent }: SourceControlBranchDetailProps) {
  if (!entry) return <div className="source-control-branch-detail" data-prototype-position="branch-detail"><Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="选择一项，查看成果与使用位置" /></div>;
  const current = entry.kind === 'local' && entry.name === worktree.branch;
  const elsewhere = !current && Boolean(occupied);
  const tracked = trackingSummary(entry);

  return <section className="source-control-branch-detail" data-prototype-position="branch-detail" aria-label="分支（Branch）详情">
    <header className="source-control-branch-detail-heading">
      <span className="source-control-branch-eyebrow">{repositoryName} · 正在查看</span>
      <div><BranchesOutlined /><h2>{entry.name}</h2>{current && <span className="source-control-branch-badge is-current"><CheckOutlined />当前使用</span>}</div>
      <small>{entry.kind === 'local' ? '本地分支（Local Branch）' : `远程分支（Remote Branch） · ${entry.remote || 'origin'}`}</small>
    </header>

    <section className="source-control-branch-result" aria-label="最近成果">
      <h3>最近成果</h3>
      <p>{entry.subject}</p>
      <div className="source-control-branch-result-meta"><code>{entry.tip.slice(0, 8)}</code><span>{entry.author}</span><span>{formatShortDateTime(entry.updatedAt)}</span></div>
      {entry.taskTitle && <div className="source-control-branch-detail-task">关联任务（Task）<strong>{entry.taskTitle}</strong></div>}
      {entry.upstream && <div className="source-control-branch-tracking"><span>上游（Upstream）</span><code>{entry.upstream}</code><small>{tracked}</small></div>}
    </section>

    <section className="source-control-branch-location" aria-label="当前使用关系">
      <h3>{elsewhere ? '已在其他位置使用' : '当前工作位置'}</h3>
      {elsewhere && occupied ? <>
        <strong>{occupied.name}</strong><code>{occupied.location}</code>
        <p>可直接打开已有工作位置，接续这里的成果。</p>
      </> : <>
        <strong>{worktree.name}</strong><code>{worktree.location}</code>
        <div className="source-control-branch-current"><span>当前使用</span><code>{worktree.branch || '未绑定分支（Branch）'}</code><small>{worktree.fileCount == null ? '变更状态待确认' : worktree.fileCount ? `${worktree.fileCount} 个文件有未提交改动（Uncommitted Changes）` : '没有未提交改动（Uncommitted Changes）'}</small></div>
        <p>{current ? '这就是此处正在使用的版本，可查看历史或继续工作。' : entry.kind === 'remote' ? '使用此成果时，将建立或复用对应的本地分支（Local Branch）。' : '切换会改变此处的文件，操作前会检查并说明现有改动的影响。'}</p>
      </>}
    </section>

    <div className="source-control-branch-actions" data-prototype-position="branch-actions">
      <Button type="primary" aria-label="查看历史" icon={<HistoryOutlined />} onClick={onViewHistory}>查看历史</Button>
      <Button aria-label="准备请求" data-prototype-position="branch-agent" icon={<RobotOutlined />} onClick={onAgent}>准备请求</Button>
      {elsewhere ? <Button aria-label="打开所在位置" icon={<ArrowRightOutlined />} onClick={onOpenWorktree}>打开所在位置</Button> : <Button aria-label="在当前工作位置使用" onClick={onUse} disabled={current}>在当前工作位置使用</Button>}
    </div>
    <section className="source-control-branch-agent">
      <div><RobotOutlined /><strong>让智能体（Agent）继续处理</strong></div>
      <p>准备包含工作对象与约束的请求，可编辑并复制后交给智能体（Agent）。此处尚未执行。</p>
    </section>
  </section>;
}
