import { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { MemoryRouter } from 'react-router-dom';
import { App, Button, ConfigProvider, Tag } from 'antd';
import zhCN from 'antd/locale/zh_CN';
import { BranchesOutlined, FolderOpenOutlined, PlusOutlined, SearchOutlined } from '@ant-design/icons';
import { AppShellHeader, AppShellFrame } from '../../app/AppShellView';
import { AppShellContext, type AppShellContextValue } from '../../app/AppShellContext';
import { AppNavigationItem } from '../../app/AppNavigationItem';
import { ObjectTabStrip } from '../../components/ObjectTabStrip';
import { softProductTheme } from '../../theme';
import { usePrototypeBridge } from '../prototype-bridge';
import { MockBranchWorkbench } from './MockBranchWorkbench';
import scenes from './scenes.json';
import 'antd/dist/reset.css';
import '../../styles.css';
import '../source-control/preview.css';
import './preview.css';

function Preview() {
  const { message } = App.useApp();
  const [page, setPage] = useState('history'), [state, setState] = useState('');
  const [collapsed, setCollapsed] = useState(true);
  const current = useRef({page: 'history', state: ''});
  function select(nextPage: string, nextState = '') { setPage(nextPage); setState(nextState); }
  const bridge = usePrototypeBridge(scenes.pages, current, select);
  useEffect(() => { bridge.report(page === 'full-file' ? 'history' : page, state); }, [page, state]);
  const info = () => message.info('当前展示讨论原型，请通过左侧页面和状态选择体验。');
  const shell: AppShellContextValue = {
    workspaceId: 'branch-discussion', workspace: {name: 'Buildr', rootPath: '/模拟工作空间/Buildr'},
    navigationRevision: 0, refreshNavigation: info, setWorkspace: info, openWorkspaceSettings: info,
    workspaceRegistryRevision: 0, openAgentAction: info, breadcrumbParts: [], setBreadcrumbParts: () => {},
    taskListResetToken: 0, resetTaskList: info, workspaceMenuTarget: () => ({to: '/workspace'}), forgetWorkspacePage: () => {},
  };
  return <AppShellContext.Provider value={shell}><div className="app-shell source-control-preview area-code">
    <AppShellHeader development brandHref="/workbench" workspaceName="Buildr" workspaceMenuItems={[{key: 'preview', label: 'Buildr · 原型数据', onClick: info}]}
      area="code" codeHref="/code/source-control" workbenchHref="/workbench" workspaceDestination={{to: '/workspace'}}
      actions={<><Tag bordered={false}>原型数据</Tag><Button type="text" aria-label="搜索" icon={<SearchOutlined />} onClick={info} /><Button type="text" onClick={info}>退出</Button><Button type="primary" icon={<PlusOutlined />} onClick={info}>提出新目标</Button></>} />
    <AppShellFrame sidebarCollapsed={collapsed} onToggleSidebar={() => setCollapsed(value => !value)}
      navigation={<nav className="shell-navigation" aria-label="代码导航"><p className="shell-nav-caption">代码</p>
        <AppNavigationItem name="explorer" label="资源管理器" icon={<FolderOpenOutlined />} to="/code/explorer" path="/explorer" active={false} onClick={event => {event.preventDefault(); info();}} />
        <AppNavigationItem name="source-control" label="源代码管理" icon={<BranchesOutlined />} to="/code/source-control" path="/source-control" active onClick={event => {event.preventDefault(); select('history');}} />
      </nav>}>
      <div className="workspace-pages scm-page-shell"><div className="scm-object-tabs"><ObjectTabStrip tabs={[{key: 'scm', kind: 'svc', title: '源代码管理'}]} active="scm" onActivate={() => {}} onClose={info} /><span className="scm-context-label">{page === 'history' ? '提交历史' : page === 'full-file' ? '文件阅读' : '未提交变更'}</span></div>
        <MockBranchWorkbench page={page} state={state} onNavigate={select} />
      </div>
    </AppShellFrame>
  </div></AppShellContext.Provider>;
}
createRoot(document.getElementById('root')!).render(<ConfigProvider locale={zhCN} theme={{...softProductTheme, cssVar: true, hashed: false}} wave={{disabled: true}}><App><MemoryRouter initialEntries={['/code/source-control']}><Preview /></MemoryRouter></App></ConfigProvider>);
