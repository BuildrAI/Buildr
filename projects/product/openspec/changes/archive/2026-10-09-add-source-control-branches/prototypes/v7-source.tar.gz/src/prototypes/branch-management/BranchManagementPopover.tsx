import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ComponentRef } from 'react';
import { Button, Dropdown, Input, Popover } from 'antd';
import { BranchesOutlined, CheckOutlined, CloudOutlined, DownOutlined, RightOutlined, SearchOutlined, SyncOutlined } from '@ant-design/icons';
import type { BranchEntry } from '../../features/code/components/SourceControlBranchPanel';
import type { SourceControlRepository, SourceControlWorktree } from '../../features/code/source-control-model';
import './branch-management-popover.css';

export type BranchSwitchImpact = {
  localName: string;
  same: boolean;
  occupied?: SourceControlWorktree;
  affectedFiles: string[];
  blockedReason?: string;
  needsLocalName?: boolean;
  createTracking?: boolean;
  description: string;
};

export type BranchManagementPopoverProps = {
  repository: SourceControlRepository;
  worktree: SourceControlWorktree;
  entries: BranchEntry[];
  ready: boolean;
  remoteLoading: boolean;
  remoteUpdatedAt: string;
  remoteError: string;
  onRefreshRemote(): void;
  inspect(entry: BranchEntry): BranchSwitchImpact;
  onUse(entry: BranchEntry, localName?: string): boolean;
  onOpenPosition(worktree: SourceControlWorktree): void;
  onViewChanges(): void;
};

type BranchGroup = { key: string; title: string; entries: BranchEntry[] };

function groupsFor(entries: BranchEntry[]): BranchGroup[] {
  const remotes = Array.from(new Set(entries.filter(entry => entry.kind === 'remote').map(entry => entry.remote || 'origin')));
  const order = (remote: string) => remote === 'origin' ? 0 : remote === 'upstream' ? 1 : 2;
  remotes.sort((left, right) => order(left) - order(right) || left.localeCompare(right));
  return [
    { key: 'local', title: '本地', entries: entries.filter(entry => entry.kind === 'local') },
    ...remotes.map(remote => ({ key: remote, title: remote, entries: entries.filter(entry => entry.kind === 'remote' && (entry.remote || 'origin') === remote) })),
  ];
}

export function BranchManagementPopover({ repository, worktree, entries, ready, remoteLoading, remoteUpdatedAt, remoteError, onRefreshRemote, inspect, onUse, onOpenPosition, onViewChanges }: BranchManagementPopoverProps) {
  const triggerRef = useRef<ComponentRef<typeof Button>>(null);
  const [open, setOpen] = useState(false);
  const [activeRef, setActiveRef] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [localName, setLocalName] = useState('');
  const [localError, setLocalError] = useState('');
  const [maxHeight, setMaxHeight] = useState(420);
  const worktreeName = worktree.isMain ? '主工作树' : worktree.name;
  const currentName = worktree.branch || (worktree.head ? `当前提交 ${worktree.head.slice(0, 8)}` : '尚无提交');
  const compactCurrentName = worktree.branch?.split('/').filter(Boolean).at(-1) || currentName;
  const measure = useCallback(() => {
    const rect = triggerRef.current?.getBoundingClientRect();
    if (!rect) return;
    const viewport = window.innerHeight;
    const available = Math.max(rect.top, viewport - rect.bottom) - 24;
    setMaxHeight(Math.min(420, Math.max(180, Math.min(viewport - 24, available))));
  }, []);
  const close = useCallback(() => { setOpen(false); setActiveRef(null); setLocalError(''); }, []);
  useEffect(() => {
    if (!open) return;
    measure();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      event.stopPropagation();
      if (activeRef) setActiveRef(null); else close();
    };
    window.addEventListener('resize', measure);
    window.addEventListener('scroll', measure, true);
    window.addEventListener('keydown', onKeyDown);
    return () => {
      window.removeEventListener('resize', measure);
      window.removeEventListener('scroll', measure, true);
      window.removeEventListener('keydown', onKeyDown);
    };
  }, [open, activeRef, measure, close]);
  const filtered = useMemo(() => {
    const term = query.trim().toLocaleLowerCase();
    return term ? entries.filter(entry => `${entry.name} ${entry.ref} ${entry.remote || ''}`.toLocaleLowerCase().includes(term)) : entries;
  }, [entries, query]);
  const groups = groupsFor(filtered);
  const beginAction = (entry: BranchEntry, nextOpen: boolean) => {
    if (!nextOpen) { setActiveRef(current => current === entry.ref ? null : current); return; }
    setActiveRef(entry.ref);
    setLocalName(inspect(entry).localName);
    setLocalError('');
  };
  const actionPanel = (entry: BranchEntry) => {
    const impact = inspect(entry);
    const targetName = impact.needsLocalName ? localName.trim() : impact.localName;
    const affected = impact.affectedFiles.length > 0;
    const actionLabel = impact.createTracking ? `检出并切换为 ${targetName || '此项'}` : `切换到 ${targetName || '此项'}`;
    return <section role="region" aria-label={`分支操作 · ${entry.name}`} className="branch-management-action" onClick={event => event.stopPropagation()} onContextMenu={event => event.preventDefault()} data-prototype-position="branch-switch-action">
      {impact.same ? <Button type="text" block disabled>当前已在使用</Button> : impact.occupied ? <>
        <p title={impact.occupied.location}>已在 {impact.occupied.isMain ? '主工作树' : impact.occupied.name} 使用</p>
        <Button type="text" block className="branch-management-primary-action" onClick={() => { onOpenPosition(impact.occupied!); close(); }}>打开所在位置</Button>
      </> : affected ? <>
        <p className="branch-management-warning">切换会覆盖现有改动</p>
        <ul className="branch-management-affected-files">{impact.affectedFiles.map(path => <li key={path} title={path}>{path}</li>)}</ul>
        <Button type="text" block className="branch-management-primary-action" onClick={() => { onViewChanges(); close(); }}>查看现有改动</Button>
      </> : impact.blockedReason ? <p className="branch-management-warning">{impact.blockedReason}</p> : <>
        {impact.needsLocalName && <label className="branch-management-local-name">本地分支（Local Branch）名称<Input size="small" value={localName} onChange={event => { setLocalName(event.target.value); setLocalError(''); }} aria-label="切换使用的本地分支（Local Branch）名称" onPressEnter={() => { if (targetName && onUse(entry, targetName)) close(); }} /></label>}
        {localError && <p className="branch-management-warning" role="alert">{localError}</p>}
        <Button type="text" block className="branch-management-primary-action" disabled={!targetName} title={actionLabel} onClick={() => { if (onUse(entry, impact.needsLocalName ? targetName : undefined)) close(); else setLocalError('无法切换，请核对当前状态后重试。'); }}>{actionLabel}</Button>
      </>}
    </section>;
  };
  const renderGroup = (group: BranchGroup) => <section className="branch-management-group" key={group.key} aria-label={group.title}>
    <h4>{group.title}</h4>
    {group.entries.length ? group.entries.map(entry => {
      const impact = inspect(entry);
      return <Dropdown key={entry.ref} open={activeRef === entry.ref} onOpenChange={next => beginAction(entry, next)} trigger={['click', 'contextMenu']} placement="bottomLeft" align={{ points: ['tl', 'tr'], offset: [6, 0], overflow: { adjustX: true, adjustY: true } }} autoAdjustOverflow popupRender={() => actionPanel(entry)} overlayClassName="branch-management-action-dropdown" destroyOnHidden>
        <button type="button" className={`branch-management-entry${impact.same ? ' is-current' : ''}${activeRef === entry.ref ? ' is-active' : ''}`} aria-label={`管理 ${entry.name}`} aria-expanded={activeRef === entry.ref} aria-haspopup="menu" onClick={event => event.stopPropagation()} onContextMenu={event => event.stopPropagation()} title={entry.name}>
          <span className="branch-management-entry-icon">{entry.kind === 'remote' ? <CloudOutlined /> : <BranchesOutlined />}</span>
          <strong>{entry.name}</strong>
          {impact.same ? <span className="branch-management-entry-state">当前 <CheckOutlined /></span> : impact.occupied ? <span className="branch-management-entry-state">其他位置使用</span> : <RightOutlined className="branch-management-entry-more" />}
        </button>
      </Dropdown>;
    }) : <p className="branch-management-none">{query.trim() ? '没有匹配项' : '暂无本地记录'}</p>}
  </section>;
  const content = <section role="region" aria-label={`分支管理 · ${repository.name} · ${worktreeName}`} className="branch-management-panel" style={{ maxHeight }} onClick={event => event.stopPropagation()} data-prototype-position="work-position-branch-manager">
    <header className="branch-management-scope" title={worktree.location}>{repository.name} · {worktreeName}</header>
    <div className="branch-management-search"><Input size="small" value={query} allowClear onChange={event => { setQuery(event.target.value); setActiveRef(null); }} prefix={<SearchOutlined />} placeholder="搜索分支名称" aria-label="搜索可用分支（Branch）" /></div>
    <div className="branch-management-list">
      {renderGroup(groups[0])}
      <div className="branch-management-remote-heading"><CloudOutlined /><span>远程</span></div>
      {groups.length > 1 ? groups.slice(1).map(renderGroup) : <p className="branch-management-none">{query.trim() ? '没有匹配项' : '暂无远程记录'}</p>}
    </div>
    <footer><span>{remoteLoading ? '正在更新远程记录…' : remoteUpdatedAt ? `上次更新 ${remoteUpdatedAt}` : '远程记录尚未更新'}</span><Button type="text" size="small" icon={<SyncOutlined spin={remoteLoading} />} disabled={remoteLoading} onClick={onRefreshRemote} aria-label="更新远程分支（Remote Branch）记录" title="更新远程记录" />{remoteError && <p role="alert">{remoteError}</p>}</footer>
  </section>;
  return <Popover open={open} onOpenChange={next => { if (next) { measure(); setOpen(true); } else close(); }} trigger="click" placement="rightTop" autoAdjustOverflow content={content} overlayClassName="branch-management-popover" destroyOnHidden>
    <Button ref={triggerRef} type="text" size="small" className="source-control-row-action-button" disabled={!ready} title={`${currentName} · 管理分支`} aria-label={`管理分支 · ${repository.name} · ${worktreeName}`} aria-expanded={open} aria-haspopup="menu" onClick={event => event.stopPropagation()}><span className="source-control-row-branch-name">{compactCurrentName}</span><DownOutlined /></Button>
  </Popover>;
}
